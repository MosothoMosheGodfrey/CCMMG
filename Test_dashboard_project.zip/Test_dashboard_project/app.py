from flask import Flask, render_template, request

app = Flask(__name__)

# Dummy data....
sample_data = [
    {"name": "John", "age": 30, "city": "Ekapa"},
    {"name": "Moshe", "age": 25, "city": "Pretoria"},
    {"name": "Rasta", "age": 35, "city": "Jonannesburg"},
    {"name": "Fire ball", "age": 28, "city": "Cape Town"},
]

import pandas as pd
df = pd.DataFrame(sample_data)
print(df)

@app.route('/', methods=['GET', 'POST'])
def dashboard():
    if request.method == 'POST':
        search_name = request.form['search_name']
        # Filter the sample data based on the search criteria
        search_results = [row for row in sample_data if search_name.lower() in row['name'].lower()]
        print(search_results,'>>>>>>>>>>>>>>>>>>>>>>')
        return render_template('dashboard.html', data=search_results, search_name=search_name)

    return render_template('dashboard.html', data=None, search_name=None)

if __name__ == '__main__':
    app.run(debug=True)
